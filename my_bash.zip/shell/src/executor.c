#include "../include/executor.h"
#include <stdio.h>
#include <sys/wait.h>

char* commands_buffer[MAX_COMMAND_CNT];

int ExecuteCommandInFork(command* command) {

	if (!command->args) return -1;

    int n_args = 0;
    argseq* start = command->args;
    do {
        commands_buffer[n_args++] = start->arg;
        start = start->next;
    } while(start != command->args && start);

    commands_buffer[n_args] = NULL;

    for (int i = 0; builtins_table[i].name != NULL; i++) {
        if (strncmp(builtins_table[i].name, commands_buffer[0], strlen(commands_buffer[0])) == 0) {
            return (*builtins_table[i].fun)(commands_buffer);
        }
    }


    int id = execvp(commands_buffer[0], commands_buffer);


    if (id == -1) {
        switch (errno) {
            case ENOENT:
                return ENOENT;
            case EACCES:
                return EACCES;
            default:
                return errno;
        }
    } 

    return OK_STATUS;
}       

int ExecuteFork(command* command) {
    if (command == NULL) {
        return OK_STATUS;
    }

    pid_t pid, wpid;
    int status;
    pid = fork();

    if (pid == 0) {
        printf("Child process Process ID (PID): %d\n", getpid());
        // Child process
        int respond = ExecuteCommandInFork(command);
        switch (respond) {
            case ENOENT:
                fprintf(stderr, "%s: no such file or directory\n", command->args->arg);
                exit(EXIT_FAILURE);
                break;
            case EACCES:
                fprintf(stderr, "%s: permission denied\n", command->args->arg);
                exit(EXIT_FAILURE);
                break;
            case OK_STATUS:
                break;
            default:
                fprintf(stderr, "%s: exec error\n", command->args->arg);
                exit(EXIT_FAILURE);
        }
        printf("Child process finished Process ID (PID): %d\n", getpid());
        exit(EXIT_SUCCESS);
    } else if (pid < 0) {
        // Error forking
        fprintf(stderr, "%s: exec error\n", command->args->arg);
        exit(EXIT_FAILURE); // Terminate the child process
    } else  {
        printf("Parent process waiting Process ID (PID): %d\n", getpid());

        // Parent process
        wpid = waitpid(pid, &status, 0);
        if (wpid == -1) {
            exit(EXIT_FAILURE);
        }

        printf("Parent process stopped waiting Process ID (PID): %d\n", getpid());
    }

    return OK_STATUS;
}

int ExecuteCommands(commandseq* commands) {
    if (commands == NULL) {
        return OK_STATUS;
    }

    commandseq* start = commands;
    do {
        int status = ExecuteFork(commands->com);
        if (status != OK_STATUS) {
            return status;
        }
        commands = commands->next;
    } while(commands != start);
    return OK_STATUS;
}

int Execute(pipelineseq* seq) {
    if (seq == NULL) {
        return OK_STATUS;
    }

    pipelineseq* start = seq;
    do {
        int status = ExecuteCommands(seq->pipeline->commands);
        seq = seq->next;
    } while(start != seq);

    return OK_STATUS;
}