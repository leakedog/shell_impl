#include <stdio.h>

#include "../include/config.h"
#include "../include/siparse.h"
#include "../include/utils.h"
#include "../include/executor.h"
#include "../include/shell.h"


int main(int argc, char *argv[])
{
	RunShell();
	return 0;
}
